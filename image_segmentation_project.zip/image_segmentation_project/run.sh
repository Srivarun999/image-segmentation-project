#!/usr/bin/env bash
# run.sh  –  convenience launcher
# Usage:
#   ./run.sh app       → start Streamlit
#   ./run.sh flask     → start Flask backend
#   ./run.sh both      → start both (Streamlit + Flask in background)
#   ./run.sh test      → run pytest
#   ./run.sh install   → create venv + install requirements

set -e

MODE=${1:-app}

activate_venv() {
    if [ -d "venv" ]; then
        source venv/bin/activate
    else
        echo "⚠️  No venv found — using system Python"
    fi
}

case "$MODE" in
    install)
        echo "📦  Creating virtual environment…"
        python3 -m venv venv
        source venv/bin/activate
        pip install --upgrade pip
        pip install -r requirements.txt
        echo "✅  Installation complete."
        ;;
    app)
        activate_venv
        echo "🚀  Starting Streamlit app on http://localhost:8501"
        streamlit run app.py --server.port 8501
        ;;
    flask)
        activate_venv
        echo "🌐  Starting Flask API on http://localhost:5000"
        python backend/flask_api.py --debug
        ;;
    both)
        activate_venv
        echo "🌐  Starting Flask API in background…"
        python backend/flask_api.py &
        FLASK_PID=$!
        echo "Flask PID: $FLASK_PID"
        echo "🚀  Starting Streamlit app…"
        streamlit run app.py --server.port 8501
        kill $FLASK_PID
        ;;
    test)
        activate_venv
        echo "🧪  Running tests…"
        pytest tests/ -v --tb=short
        ;;
    *)
        echo "Unknown mode: $MODE"
        echo "Usage: ./run.sh [install|app|flask|both|test]"
        exit 1
        ;;
esac
