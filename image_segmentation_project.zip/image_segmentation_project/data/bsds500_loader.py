"""
data/bsds500_loader.py
BSDS500 dataset utilities:
  – download / extract the dataset
  – iterate images and ground-truth segmentation masks
  – benchmark a segmentation function against human annotations

Dataset URL (official mirror):
  https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html
"""

import os
import json
import glob
import urllib.request
import tarfile
from pathlib import Path

import numpy as np
import cv2
from scipy.io import loadmat

# ── Constants ──────────────────────────────────────────────────────────────────
BSDS500_URL   = "http://www.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/BSR/BSR_bsds500.tgz"
DEFAULT_ROOT  = os.path.join(os.path.dirname(__file__), "BSR")


class BSDS500Dataset:
    """
    Lightweight iterator over the BSDS500 dataset.

    Parameters
    ----------
    root    : path to the extracted BSR folder
    split   : 'train' | 'val' | 'test'
    """

    def __init__(self, root: str = DEFAULT_ROOT, split: str = "train"):
        self.root  = Path(root)
        self.split = split
        self.img_dir   = self.root / "BSDS500" / "data" / "images"   / split
        self.gt_dir    = self.root / "BSDS500" / "data" / "groundTruth" / split

        if not self.img_dir.exists():
            raise FileNotFoundError(
                f"BSDS500 not found at {self.img_dir}.\n"
                "Run BSDS500Dataset.download() first, or place the extracted "
                "BSR folder under data/."
            )

        self.image_ids = [
            p.stem for p in sorted(self.img_dir.glob("*.jpg"))
        ]

    def __len__(self) -> int:
        return len(self.image_ids)

    def __getitem__(self, idx: int) -> dict:
        img_id = self.image_ids[idx]
        img    = cv2.cvtColor(
            cv2.imread(str(self.img_dir / f"{img_id}.jpg")),
            cv2.COLOR_BGR2RGB
        )
        gt_path = self.gt_dir / f"{img_id}.mat"
        gts     = _load_gt(gt_path) if gt_path.exists() else []
        return {"id": img_id, "image": img, "gt_segmentations": gts}

    def iter_images(self):
        for i in range(len(self)):
            yield self[i]

    @staticmethod
    def download(root: str = DEFAULT_ROOT):
        """
        Download and extract BSDS500 into `root`.
        Skips download if already present.
        """
        os.makedirs(root, exist_ok=True)
        tgz_path = os.path.join(root, "BSR_bsds500.tgz")
        if not os.path.exists(tgz_path):
            print(f"Downloading BSDS500 from {BSDS500_URL} …")
            urllib.request.urlretrieve(BSDS500_URL, tgz_path,
                                       reporthook=_dl_progress)
            print("\nDownload complete.")
        else:
            print("Archive already present — skipping download.")

        print("Extracting …")
        with tarfile.open(tgz_path, "r:gz") as tar:
            tar.extractall(path=root)
        print(f"Extracted to {root}")


# ── Benchmarking ───────────────────────────────────────────────────────────────

def benchmark_segmentation(
    seg_func,
    dataset: "BSDS500Dataset",
    max_images: int = 50,
    **seg_kwargs,
) -> dict:
    """
    Run `seg_func(image) -> labels` on BSDS500 and compute:
      – mean Boundary F-measure (BF)
      – mean Variation of Information (VI)
      – mean Probabilistic Rand Index (PRI)

    Parameters
    ----------
    seg_func   : callable (H×W×3 uint8) → (H×W) int label array
    dataset    : BSDS500Dataset instance
    max_images : number of images to evaluate (sub-sample for speed)
    **seg_kwargs : extra args forwarded to seg_func
    """
    from utils.bsds_metrics import boundary_f_measure, variation_of_info, prob_rand_index

    bf_scores  = []
    vi_scores  = []
    pri_scores = []

    indices = np.random.choice(len(dataset), min(max_images, len(dataset)), replace=False)
    for i, idx in enumerate(indices):
        sample = dataset[int(idx)]
        img    = sample["image"]
        gts    = sample["gt_segmentations"]
        if not gts:
            continue

        labels = seg_func(img, **seg_kwargs)

        # Average over all human annotations
        bf_list, vi_list, pri_list = [], [], []
        for gt in gts:
            if gt.shape != labels.shape:
                gt = cv2.resize(gt.astype(np.float32), (labels.shape[1], labels.shape[0]),
                                interpolation=cv2.INTER_NEAREST).astype(np.int32)
            bf_list.append(boundary_f_measure(labels, gt))
            vi_list.append(variation_of_info(labels, gt))
            pri_list.append(prob_rand_index(labels, gt))

        bf_scores.append(np.mean(bf_list))
        vi_scores.append(np.mean(vi_list))
        pri_scores.append(np.mean(pri_list))
        print(f"  [{i+1}/{len(indices)}] id={sample['id']}  "
              f"BF={bf_scores[-1]:.3f}  VI={vi_scores[-1]:.3f}  PRI={pri_scores[-1]:.3f}")

    return {
        "mean_BF":  float(np.mean(bf_scores)),
        "mean_VI":  float(np.mean(vi_scores)),
        "mean_PRI": float(np.mean(pri_scores)),
        "n_images": len(bf_scores),
    }


# ── Private helpers ────────────────────────────────────────────────────────────

def _load_gt(mat_path: Path) -> list[np.ndarray]:
    """Load all human segmentation annotations from a .mat file."""
    mat  = loadmat(str(mat_path))
    gts  = []
    segs = mat.get("groundTruth", np.array([[]])).flatten()
    for ann in segs:
        try:
            seg = ann["Segmentation"][0, 0].astype(np.int32)
            gts.append(seg)
        except Exception:
            pass
    return gts


def _dl_progress(block_num, block_size, total_size):
    downloaded = block_num * block_size
    pct        = downloaded / total_size * 100 if total_size > 0 else 0
    print(f"\r  {pct:.1f}% ({downloaded // 1_048_576} MB)", end="", flush=True)
