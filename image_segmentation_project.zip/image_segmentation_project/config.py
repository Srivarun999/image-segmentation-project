"""
config.py
Central configuration constants for the Image Segmentation Studio.
Edit these values to tune defaults across the entire application.
"""

# ── App meta ───────────────────────────────────────────────────────────────────
APP_TITLE   = "Image Segmentation Studio"
APP_VERSION = "1.0.0"
APP_ICON    = "🔬"

# ── Default image pre-processing ───────────────────────────────────────────────
DEFAULT_RESIZE_DIM   = 256     # pixels (square)
DEFAULT_COLOR_SPACE  = "LAB"   # "RGB" | "LAB" | "HSV" | "Grayscale"
DEFAULT_USE_SPATIAL  = True    # append row/col features
DEFAULT_GAUSSIAN_BLUR= False
DEFAULT_BLUR_SIGMA   = 1.0

# ── Cluster tendency ───────────────────────────────────────────────────────────
HOPKINS_N_SAMPLES   = 150
HOPKINS_THRESHOLD   = 0.75   # H > threshold → strong clustering tendency
GAP_MAX_K           = 8
GAP_N_REFS          = 10

# ── Algorithm defaults ─────────────────────────────────────────────────────────
KMEANS_N_CLUSTERS   = 5
KMEANS_INIT         = "k-means++"
KMEANS_MAX_ITER     = 300
KMEANS_N_INIT       = 10

DBSCAN_EPS          = 0.5
DBSCAN_MIN_SAMPLES  = 5
DBSCAN_METRIC       = "euclidean"

GMM_N_COMPONENTS    = 5
GMM_COV_TYPE        = "full"
GMM_MAX_ITER        = 200
GMM_N_INIT          = 3

# ── Metric computation ─────────────────────────────────────────────────────────
SILHOUETTE_MAX_SAMPLES  = 5_000
ELBOW_K_RANGE           = range(2, 13)
BIC_AIC_K_RANGE         = range(2, 13)

# ── Flask backend ──────────────────────────────────────────────────────────────
FLASK_HOST          = "0.0.0.0"
FLASK_PORT          = 5000
FLASK_DEFAULT_URL   = "http://localhost:5000"

# ── BSDS500 ────────────────────────────────────────────────────────────────────
BSDS500_ROOT        = "data/BSR"
BSDS500_DEFAULT_SPLIT = "val"
BSDS500_BENCHMARK_N   = 50    # images to evaluate by default

# ── Visualisation ──────────────────────────────────────────────────────────────
VIS_MAX_PCA_POINTS  = 2_000
VIS_FIGSIZE_SQUARE  = (5, 5)
VIS_FIGSIZE_WIDE    = (10, 4)
VIS_CMAP_SEG        = "nipy_spectral"
VIS_CMAP_FEATURE    = "tab20"

# ── Logging ────────────────────────────────────────────────────────────────────
LOG_LEVEL           = "INFO"
