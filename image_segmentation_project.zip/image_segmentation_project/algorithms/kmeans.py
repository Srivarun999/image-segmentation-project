"""
algorithms/kmeans.py
K-Means segmentation wrapper with elbow analysis helpers.
"""

import numpy as np
from sklearn.cluster import KMeans, MiniBatchKMeans
from sklearn.metrics import silhouette_score


def run_kmeans(
    features: np.ndarray,
    n_clusters: int = 5,
    init: str = "k-means++",
    max_iter: int = 300,
    n_init: int = 10,
    use_minibatch: bool = False,
    random_state: int = 42,
) -> np.ndarray:
    """
    Run K-Means on feature matrix and return a flat label array.

    Parameters
    ----------
    features     : (N, F) standardised feature matrix
    n_clusters   : number of clusters K
    init         : initialisation strategy  'k-means++' | 'random'
    max_iter     : maximum EM iterations
    n_init       : number of random restarts
    use_minibatch: use MiniBatchKMeans for large datasets (faster)
    random_state : RNG seed

    Returns
    -------
    labels : (N,) integer label array
    """
    KMeansCls = MiniBatchKMeans if use_minibatch or features.shape[0] > 50_000 else KMeans

    model = KMeansCls(
        n_clusters=n_clusters,
        init=init,
        max_iter=max_iter,
        n_init=n_init,
        random_state=random_state,
    )
    labels = model.fit_predict(features)
    return labels.astype(np.int32)


def elbow_analysis(
    features: np.ndarray,
    k_range: range = range(2, 12),
    random_state: int = 42,
) -> tuple[list[float], list[float]]:
    """
    Compute inertia (SSE) and silhouette scores for a range of K.

    Returns
    -------
    inertias    : list of SSE values
    sil_scores  : list of silhouette scores
    """
    inertias   = []
    sil_scores = []

    # Sub-sample for speed
    if features.shape[0] > 5000:
        idx  = np.random.choice(features.shape[0], 5000, replace=False)
        feat = features[idx]
    else:
        feat = features

    for k in k_range:
        km     = KMeans(n_clusters=k, init="k-means++", n_init=5,
                        random_state=random_state)
        labels = km.fit_predict(feat)
        inertias.append(km.inertia_)
        if k > 1:
            sil_scores.append(silhouette_score(feat, labels, sample_size=min(2000, len(feat))))
        else:
            sil_scores.append(0.0)

    return inertias, sil_scores


def find_optimal_k_elbow(inertias: list[float]) -> int:
    """
    Find the elbow point using the Kneedle algorithm (simplified).

    Parameters
    ----------
    inertias : list of SSE values for k = 2, 3, …

    Returns
    -------
    optimal index (1-based = k value starting from 2)
    """
    inertias = np.array(inertias, dtype=float)
    n        = len(inertias)
    if n < 3:
        return 2

    # Normalise
    x  = np.arange(n, dtype=float)
    x /= x.max()
    y  = (inertias - inertias.min()) / (inertias.max() - inertias.min() + 1e-12)

    # Knee = max distance from the line connecting first and last point
    line_vec  = np.array([x[-1] - x[0], y[-1] - y[0]])
    line_vec /= np.linalg.norm(line_vec) + 1e-12
    vecs      = np.c_[x - x[0], y - y[0]]
    dists     = np.abs(np.cross(line_vec, vecs))
    return int(np.argmax(dists)) + 2   # offset because we start at k=2
