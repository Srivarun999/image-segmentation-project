"""
algorithms/dbscan.py
DBSCAN segmentation wrapper with automatic eps estimation.
"""

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors


def run_dbscan(
    features: np.ndarray,
    eps: float = 0.5,
    min_samples: int = 5,
    metric: str = "euclidean",
    n_jobs: int = -1,
) -> np.ndarray:
    """
    Run DBSCAN on feature matrix.

    Parameters
    ----------
    features    : (N, F) standardised feature matrix
    eps         : neighbourhood radius ε
    min_samples : minimum neighbours to be a core point
    metric      : distance metric ('euclidean' | 'manhattan' | 'cosine')
    n_jobs      : parallel workers (−1 = all cores)

    Returns
    -------
    labels : (N,) integer label array, −1 = noise
    """
    model  = DBSCAN(eps=eps, min_samples=min_samples, metric=metric, n_jobs=n_jobs)
    labels = model.fit_predict(features)
    return labels.astype(np.int32)


def estimate_eps(
    features: np.ndarray,
    min_samples: int = 5,
    percentile: float = 90.0,
) -> float:
    """
    Estimate a reasonable eps using the k-NN distance plot heuristic.

    The k-th NN distance at `percentile` of the sorted distance distribution
    is returned as the suggested ε.

    Parameters
    ----------
    features    : (N, F) feature matrix
    min_samples : corresponds to k in k-NN
    percentile  : which percentile of k-NN distances to use

    Returns
    -------
    eps : suggested float value
    """
    if features.shape[0] > 5000:
        idx      = np.random.choice(features.shape[0], 5000, replace=False)
        feat_sub = features[idx]
    else:
        feat_sub = features

    nbrs   = NearestNeighbors(n_neighbors=min_samples).fit(feat_sub)
    dists, _ = nbrs.kneighbors(feat_sub)
    k_dists  = np.sort(dists[:, -1])
    return float(np.percentile(k_dists, percentile))


def dbscan_summary(labels: np.ndarray) -> dict:
    """Return a summary dict for a DBSCAN label array."""
    unique    = np.unique(labels)
    n_clusters = np.sum(unique >= 0)
    n_noise    = np.sum(labels == -1)
    noise_pct  = n_noise / len(labels) * 100
    return {
        "n_clusters":  int(n_clusters),
        "n_noise":     int(n_noise),
        "noise_pct":   round(noise_pct, 2),
        "cluster_ids": unique[unique >= 0].tolist(),
    }
