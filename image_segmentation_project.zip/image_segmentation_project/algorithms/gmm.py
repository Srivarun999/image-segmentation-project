"""
algorithms/gmm.py
Gaussian Mixture Model (GMM) segmentation wrapper.
"""

import numpy as np
from sklearn.mixture import GaussianMixture


def run_gmm(
    features: np.ndarray,
    n_components: int = 5,
    covariance_type: str = "full",
    max_iter: int = 200,
    n_init: int = 3,
    random_state: int = 42,
) -> np.ndarray:
    """
    Fit a GMM and return hard cluster assignments.

    Parameters
    ----------
    features        : (N, F) standardised feature matrix
    n_components    : number of Gaussian components
    covariance_type : 'full' | 'tied' | 'diag' | 'spherical'
    max_iter        : EM iterations
    n_init          : number of random initialisations
    random_state    : RNG seed

    Returns
    -------
    labels : (N,) integer label array
    """
    model  = GaussianMixture(
        n_components=n_components,
        covariance_type=covariance_type,
        max_iter=max_iter,
        n_init=n_init,
        random_state=random_state,
    )
    labels = model.fit_predict(features)
    return labels.astype(np.int32)


def run_gmm_soft(
    features: np.ndarray,
    n_components: int = 5,
    covariance_type: str = "full",
    max_iter: int = 200,
    random_state: int = 42,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Fit a GMM and return both hard labels and soft probabilities.

    Returns
    -------
    labels : (N,) hard assignments
    probs  : (N, K) posterior probabilities
    """
    model = GaussianMixture(
        n_components=n_components,
        covariance_type=covariance_type,
        max_iter=max_iter,
        random_state=random_state,
    )
    model.fit(features)
    labels = model.predict(features)
    probs  = model.predict_proba(features)
    return labels.astype(np.int32), probs


def bic_aic_analysis(
    features: np.ndarray,
    k_range: range = range(2, 12),
    covariance_type: str = "full",
    random_state: int = 42,
) -> tuple[list[float], list[float]]:
    """
    Compute BIC and AIC for a range of components to find optimal K.

    Returns
    -------
    bic_scores : list of BIC values
    aic_scores : list of AIC values
    """
    bic_scores = []
    aic_scores = []

    if features.shape[0] > 5000:
        idx  = np.random.choice(features.shape[0], 5000, replace=False)
        feat = features[idx]
    else:
        feat = features

    for k in k_range:
        gm  = GaussianMixture(
            n_components=k, covariance_type=covariance_type,
            max_iter=200, n_init=3, random_state=random_state
        )
        gm.fit(feat)
        bic_scores.append(gm.bic(feat))
        aic_scores.append(gm.aic(feat))

    return bic_scores, aic_scores
