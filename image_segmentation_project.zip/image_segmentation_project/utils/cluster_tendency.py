"""
utils/cluster_tendency.py
Cluster tendency measures:  Hopkins Statistic & Gap Statistic.
"""

import numpy as np
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors


# ─────────────────────────────────────────────────────────────────────────────
# Hopkins Statistic
# ─────────────────────────────────────────────────────────────────────────────

def hopkins_statistic(X: np.ndarray, n_samples: int = 150) -> tuple[float, str]:
    """
    Compute the Hopkins statistic for dataset X.

    H ≈ 0.5  →  random (no structure)
    H → 1.0  →  strong cluster tendency
    H → 0.0  →  regular / uniform lattice

    Parameters
    ----------
    X         : (N, F) feature matrix
    n_samples : number of random points to sample

    Returns
    -------
    h         : Hopkins statistic (float)
    interp    : human-readable interpretation (str)
    """
    n_samples = min(n_samples, X.shape[0] - 1)
    d         = X.shape[1]

    # Min/max per dimension for random point generation
    mins = X.min(axis=0)
    maxs = X.max(axis=0)

    # ── Sample m points from X ────────────────────────────────────────────────
    idx = np.random.choice(X.shape[0], n_samples, replace=False)
    sample_X = X[idx]

    # ── Generate m random points in the bounding box ──────────────────────────
    random_pts = np.random.uniform(low=mins, high=maxs, size=(n_samples, d))

    # ── 1-NN distances ────────────────────────────────────────────────────────
    nbrs = NearestNeighbors(n_neighbors=2, algorithm="ball_tree").fit(X)

    # u_i: NN distance from random point to X
    u_dists, _ = nbrs.kneighbors(random_pts)
    u = u_dists[:, 0]

    # w_i: NN distance from sampled X point to remaining X (exclude self)
    w_dists, _ = nbrs.kneighbors(sample_X)
    w = w_dists[:, 1]   # index 0 is self

    u_sum = np.sum(u**d)
    w_sum = np.sum(w**d)

    h = u_sum / (u_sum + w_sum + 1e-12)

    # ── Interpretation ─────────────────────────────────────────────────────────
    if h > 0.75:
        interp = "Strong clustering tendency — proceed with segmentation ✅"
    elif h > 0.5:
        interp = "Moderate tendency — clustering may be useful ⚠️"
    else:
        interp = "Weak / no clustering tendency — data may be random 🔴"

    return float(h), interp


# ─────────────────────────────────────────────────────────────────────────────
# Gap Statistic
# ─────────────────────────────────────────────────────────────────────────────

def gap_statistic(
    X: np.ndarray,
    max_k: int = 8,
    n_refs: int = 10,
    random_state: int = 42,
) -> tuple[list[float], int, str]:
    """
    Compute the Gap Statistic to find the optimal number of clusters K.

    Parameters
    ----------
    X            : (N, F) feature matrix (use a subsample for speed)
    max_k        : maximum K to evaluate
    n_refs       : number of random reference datasets
    random_state : RNG seed

    Returns
    -------
    gaps         : list of Gap values for k = 1…max_k
    optimal_k    : suggested optimal K
    interp       : human-readable interpretation
    """
    np.random.seed(random_state)

    # Sub-sample for speed (≤ 3000 points)
    if X.shape[0] > 3000:
        idx = np.random.choice(X.shape[0], 3000, replace=False)
        X = X[idx]

    mins = X.min(axis=0)
    maxs = X.max(axis=0)

    gaps    = []
    s_k     = []

    for k in range(1, max_k + 1):
        # ── Actual clustering ─────────────────────────────────────────────────
        km   = KMeans(n_clusters=k, init="k-means++", n_init=5, random_state=random_state)
        km.fit(X)
        w_k  = _within_cluster_dispersion(X, km.labels_, k)

        # ── Reference datasets ────────────────────────────────────────────────
        ref_dispersions = []
        for _ in range(n_refs):
            ref = np.random.uniform(low=mins, high=maxs, size=X.shape)
            km_ref = KMeans(n_clusters=k, init="k-means++", n_init=3,
                            random_state=random_state)
            km_ref.fit(ref)
            ref_dispersions.append(_within_cluster_dispersion(ref, km_ref.labels_, k))

        ref_log  = np.log(np.array(ref_dispersions) + 1e-12)
        gap_k    = ref_log.mean() - np.log(w_k + 1e-12)
        std_k    = ref_log.std() * np.sqrt(1 + 1 / n_refs)

        gaps.append(gap_k)
        s_k.append(std_k)

    # ── Find optimal K using gap(k) ≥ gap(k+1) - s(k+1) ─────────────────────
    optimal_k = 1
    for k in range(1, max_k):
        if gaps[k - 1] >= gaps[k] - s_k[k]:
            optimal_k = k
            break
    else:
        optimal_k = int(np.argmax(gaps)) + 1

    interp = (
        f"Gap Statistic suggests K = {optimal_k} as the optimal number of clusters. "
        "Use this as a starting point for K-Means / GMM."
    )

    return gaps, optimal_k, interp


def _within_cluster_dispersion(X: np.ndarray, labels: np.ndarray, k: int) -> float:
    """Sum of intra-cluster squared distances (W_k)."""
    disp = 0.0
    for c in range(k):
        pts = X[labels == c]
        if len(pts) < 2:
            continue
        centroid = pts.mean(axis=0)
        disp += np.sum((pts - centroid) ** 2)
    return disp / (X.shape[0] + 1e-12)
