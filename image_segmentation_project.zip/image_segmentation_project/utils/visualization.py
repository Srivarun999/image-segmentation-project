"""
utils/visualization.py
All matplotlib/seaborn plotting helpers for the Streamlit app.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sklearn.decomposition import PCA


# ── Color palette ──────────────────────────────────────────────────────────────
CMAP_SEG = plt.cm.get_cmap("tab20", 20)


def plot_segmented_image(
    original: np.ndarray,
    labels: np.ndarray,
    title: str = "Segmentation",
) -> plt.Figure:
    """
    Colour-map the label image.

    Parameters
    ----------
    original : H×W×3 float or uint8 image
    labels   : H×W int array of cluster labels
    """
    fig, ax = plt.subplots(figsize=(5, 5))
    n_labels = labels.max() + 1 if labels.max() >= 0 else 1
    cmap     = plt.cm.get_cmap("nipy_spectral", max(n_labels, 2))

    label_vis = labels.astype(float)
    label_vis[labels == -1] = np.nan          # noise → transparent

    im = ax.imshow(label_vis, cmap=cmap, interpolation="nearest", vmin=0, vmax=n_labels - 1)
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="Cluster")
    ax.set_title(title, fontsize=12, fontweight="bold")
    ax.axis("off")
    plt.tight_layout()
    return fig


def plot_side_by_side(
    original: np.ndarray,
    labels: np.ndarray,
) -> plt.Figure:
    """Original image next to mean-colour segmentation."""
    H, W = labels.shape
    img  = original.copy()
    if img.max() <= 1.0:
        img = (img * 255).astype(np.uint8)

    # Build mean-colour image
    seg_img = np.zeros_like(img)
    for lbl in np.unique(labels):
        if lbl < 0:
            continue
        mask             = labels == lbl
        seg_img[mask]    = img[mask].mean(axis=0).astype(np.uint8)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].imshow(img);      axes[0].set_title("Original",    fontsize=11); axes[0].axis("off")
    axes[1].imshow(seg_img);  axes[1].set_title("Segmented",   fontsize=11); axes[1].axis("off")
    plt.suptitle("Original vs Segmented", fontsize=13, fontweight="bold")
    plt.tight_layout()
    return fig


def plot_cluster_tendency_result(
    measure: str,
    value: float,
    threshold: float = 0.75,
) -> plt.Figure:
    """Gauge-style bar showing the tendency value vs threshold."""
    fig, ax = plt.subplots(figsize=(5, 1.4))
    bar_color = "#28a745" if value > threshold else ("#ffc107" if value > 0.5 else "#dc3545")

    ax.barh(0, value,     height=0.5, color=bar_color, label=f"{measure}: {value:.4f}")
    ax.barh(0, 1 - value, height=0.5, left=value, color="#e9ecef")
    ax.axvline(threshold, color="navy", linewidth=2, linestyle="--", label=f"Threshold: {threshold}")

    ax.set_xlim(0, 1)
    ax.set_yticks([])
    ax.set_xlabel("Statistic value")
    ax.legend(loc="lower right", fontsize=8)
    ax.set_title(f"{measure} Gauge", fontsize=10)
    plt.tight_layout()
    return fig


def plot_elbow_curve(
    gap_values: list[float],
    optimal_k: int,
) -> plt.Figure:
    """Gap statistic curve with optimal K marked."""
    ks  = list(range(1, len(gap_values) + 1))
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.plot(ks, gap_values, "bo-", linewidth=2, markersize=6, label="Gap(k)")
    ax.axvline(optimal_k, color="red", linestyle="--", linewidth=1.5, label=f"Optimal K={optimal_k}")
    ax.scatter([optimal_k], [gap_values[optimal_k - 1]], color="red", s=100, zorder=5)
    ax.set_xlabel("Number of clusters K")
    ax.set_ylabel("Gap Statistic")
    ax.set_title("Gap Statistic — Optimal K Selection", fontsize=11, fontweight="bold")
    ax.legend()
    ax.grid(alpha=0.3)
    plt.tight_layout()
    return fig


def plot_feature_space(
    features: np.ndarray,
    max_points: int = 2000,
    labels: np.ndarray | None = None,
) -> plt.Figure:
    """2D PCA scatter of the feature space."""
    if features.shape[0] > max_points:
        idx      = np.random.choice(features.shape[0], max_points, replace=False)
        feat_sub = features[idx]
        lbl_sub  = labels[idx] if labels is not None else None
    else:
        feat_sub = features
        lbl_sub  = labels

    pca   = PCA(n_components=2)
    proj  = pca.fit_transform(feat_sub)
    var   = pca.explained_variance_ratio_

    fig, ax = plt.subplots(figsize=(5, 4))
    if lbl_sub is not None:
        scatter = ax.scatter(proj[:, 0], proj[:, 1],
                             c=lbl_sub, cmap="tab20", s=4, alpha=0.6)
        plt.colorbar(scatter, ax=ax, label="Cluster")
    else:
        ax.scatter(proj[:, 0], proj[:, 1], s=4, alpha=0.4, color="#667eea")

    ax.set_xlabel(f"PC1 ({var[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({var[1]*100:.1f}%)")
    ax.set_title("Feature Space (PCA 2D)", fontsize=11, fontweight="bold")
    ax.grid(alpha=0.2)
    plt.tight_layout()
    return fig
