"""
utils/bsds_metrics.py
Segmentation quality metrics used for BSDS500 benchmarking:
  - Boundary F-measure (BF)
  - Variation of Information (VI)
  - Probabilistic Rand Index (PRI)
"""

import numpy as np
from scipy.ndimage import binary_dilation


# ── Boundary F-measure ─────────────────────────────────────────────────────────

def boundary_f_measure(
    pred_labels: np.ndarray,
    gt_labels: np.ndarray,
    tolerance: int = 2,
) -> float:
    """
    Compute the boundary F-measure between predicted and GT segmentations.

    Parameters
    ----------
    pred_labels : (H, W) int array
    gt_labels   : (H, W) int array
    tolerance   : pixel tolerance for boundary matching

    Returns
    -------
    f_score : float in [0, 1]
    """
    pred_boundary = _label_to_boundary(pred_labels)
    gt_boundary   = _label_to_boundary(gt_labels)

    # Dilate boundaries by tolerance
    struct    = np.ones((2 * tolerance + 1, 2 * tolerance + 1), dtype=bool)
    pred_dil  = binary_dilation(pred_boundary, structure=struct)
    gt_dil    = binary_dilation(gt_boundary,   structure=struct)

    tp_p  = np.sum(pred_boundary & gt_dil)
    tp_g  = np.sum(gt_boundary   & pred_dil)

    prec  = tp_p / (np.sum(pred_boundary) + 1e-10)
    rec   = tp_g / (np.sum(gt_boundary)   + 1e-10)

    if prec + rec < 1e-10:
        return 0.0
    return float(2 * prec * rec / (prec + rec))


def _label_to_boundary(labels: np.ndarray) -> np.ndarray:
    """Boolean edge map derived from a label image (4-connectivity)."""
    boundary = np.zeros_like(labels, dtype=bool)
    boundary[:-1, :] |= labels[:-1, :] != labels[1:, :]
    boundary[:, :-1] |= labels[:, :-1] != labels[:, 1:]
    return boundary


# ── Variation of Information ───────────────────────────────────────────────────

def variation_of_info(
    pred_labels: np.ndarray,
    gt_labels: np.ndarray,
) -> float:
    """
    Variation of Information: VI = H(GT|Pred) + H(Pred|GT).
    Lower is better.
    """
    N = pred_labels.size
    p_ids = np.unique(pred_labels)
    g_ids = np.unique(gt_labels[gt_labels >= 0])

    # Marginal probabilities
    p_p = np.array([np.sum(pred_labels == k) / N for k in p_ids])
    p_g = np.array([np.sum(gt_labels   == k) / N for k in g_ids])

    h_p = -np.sum(p_p * np.log2(p_p + 1e-12))
    h_g = -np.sum(p_g * np.log2(p_g + 1e-12))

    # Joint probabilities for mutual information
    mi = 0.0
    for i, ki in enumerate(p_ids):
        for j, kj in enumerate(g_ids):
            p_ij = np.sum((pred_labels == ki) & (gt_labels == kj)) / N
            if p_ij > 1e-12:
                mi += p_ij * np.log2(p_ij / (p_p[i] * p_g[j] + 1e-12))

    vi = h_p + h_g - 2 * mi
    return float(max(vi, 0.0))


# ── Probabilistic Rand Index ───────────────────────────────────────────────────

def prob_rand_index(
    pred_labels: np.ndarray,
    gt_labels: np.ndarray,
) -> float:
    """
    Probabilistic Rand Index (PRI).  Higher is better.
    Implements a fast approximation.
    """
    N    = pred_labels.size
    flat_p = pred_labels.ravel()
    flat_g = gt_labels.ravel()

    # Sample pairs for scalability
    max_pairs = 50_000
    if N > max_pairs:
        idx   = np.random.choice(N, max_pairs, replace=False)
        flat_p = flat_p[idx]
        flat_g = flat_g[idx]
        N      = max_pairs

    # Vectorised pair agreement
    from itertools import combinations

    agree = 0
    total = 0
    chunk = 5000

    for start in range(0, N, chunk):
        end  = min(start + chunk, N)
        p_ch = flat_p[start:end]
        g_ch = flat_g[start:end]

        # All pairs within chunk
        pp = (p_ch[:, None] == p_ch[None, :])
        gp = (g_ch[:, None] == g_ch[None, :])
        mask = np.triu(np.ones((len(p_ch), len(p_ch)), dtype=bool), k=1)

        agree += np.sum((pp == gp) & mask)
        total += np.sum(mask)

    return float(agree / (total + 1e-10))
