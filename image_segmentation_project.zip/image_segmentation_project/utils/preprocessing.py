"""
utils/preprocessing.py
Image pre-processing and feature extraction for segmentation.
"""

import numpy as np
import cv2
from skimage import color as sk_color
from scipy.ndimage import gaussian_filter
from sklearn.preprocessing import StandardScaler


def preprocess_image(
    image: np.ndarray,
    resize_dim: int = 256,
    color_space: str = "RGB",
    use_spatial: bool = True,
    gaussian_blur: bool = False,
    blur_sigma: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Pre-process an image and return (processed_image, feature_matrix).

    Parameters
    ----------
    image       : H×W×3 uint8 numpy array (RGB)
    resize_dim  : target side length (square)
    color_space : 'RGB' | 'LAB' | 'HSV' | 'Grayscale'
    use_spatial : append normalised (row, col) coordinates
    gaussian_blur : apply Gaussian blur before feature extraction
    blur_sigma  : sigma for Gaussian blur

    Returns
    -------
    processed   : H×W×C float image
    features    : (H*W) × F numpy array, standardised
    """

    # ── Resize ────────────────────────────────────────────────────────────────
    img = cv2.resize(image, (resize_dim, resize_dim), interpolation=cv2.INTER_AREA)
    img = img.astype(np.float32) / 255.0

    # ── Optional blur ─────────────────────────────────────────────────────────
    if gaussian_blur and blur_sigma:
        for c in range(img.shape[2]):
            img[:, :, c] = gaussian_filter(img[:, :, c], sigma=blur_sigma)

    # ── Color space conversion ─────────────────────────────────────────────────
    if color_space == "LAB":
        processed = sk_color.rgb2lab(img)
    elif color_space == "HSV":
        processed = sk_color.rgb2hsv(img)
    elif color_space == "Grayscale":
        gray = sk_color.rgb2gray(img)[:, :, np.newaxis]
        processed = np.repeat(gray, 3, axis=2)
    else:  # RGB (default)
        processed = img

    # ── Feature matrix ────────────────────────────────────────────────────────
    H, W, C = processed.shape
    features = processed.reshape(-1, C)

    if use_spatial:
        rows = np.repeat(np.linspace(0, 1, H), W).reshape(-1, 1)
        cols = np.tile(np.linspace(0, 1, W), H).reshape(-1, 1)
        features = np.hstack([features, rows, cols])

    # ── Standardise ───────────────────────────────────────────────────────────
    scaler   = StandardScaler()
    features = scaler.fit_transform(features.astype(np.float64))

    return processed, features


def extract_features(image: np.ndarray, method: str = "raw") -> np.ndarray:
    """
    Convenience wrapper that returns only the feature matrix.

    method: 'raw' | 'texture' | 'gradient'
    """
    if method == "texture":
        return _texture_features(image)
    if method == "gradient":
        return _gradient_features(image)
    _, feats = preprocess_image(image)
    return feats


# ── Private helpers ────────────────────────────────────────────────────────────

def _texture_features(image: np.ndarray) -> np.ndarray:
    """LBP-based texture feature map (simplified)."""
    gray = cv2.cvtColor((image * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    # Local standard-deviation as lightweight texture proxy
    from scipy.ndimage import generic_filter
    texture = generic_filter(gray.astype(float), np.std, size=5)
    texture_norm = (texture - texture.min()) / (texture.max() - texture.min() + 1e-8)
    H, W = gray.shape
    return texture_norm.reshape(-1, 1)


def _gradient_features(image: np.ndarray) -> np.ndarray:
    """Sobel gradient magnitude as feature."""
    gray = cv2.cvtColor((image * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
    grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    magnitude = np.sqrt(grad_x**2 + grad_y**2)
    magnitude /= magnitude.max() + 1e-8
    return magnitude.reshape(-1, 1)
