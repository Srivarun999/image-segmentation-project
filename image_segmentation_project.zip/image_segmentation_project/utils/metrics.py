"""
utils/metrics.py
Clustering quality metrics: Silhouette, Davies-Bouldin, Calinski-Harabasz.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (
    silhouette_score,
    davies_bouldin_score,
    calinski_harabasz_score,
)


def compute_metrics(X: np.ndarray, labels: np.ndarray) -> dict[str, float]:
    """
    Compute internal clustering quality metrics.

    Parameters
    ----------
    X      : (N, F) feature matrix
    labels : (N,) cluster label array (−1 = noise for DBSCAN)

    Returns
    -------
    dict with Silhouette Score, Davies-Bouldin Index, Calinski-Harabasz Index
    """
    # Remove noise points (DBSCAN label = −1) for metric computation
    mask    = labels >= 0
    X_clean = X[mask]
    l_clean = labels[mask]

    n_clusters = len(np.unique(l_clean))
    if n_clusters < 2 or len(X_clean) < n_clusters + 1:
        return {
            "Silhouette Score": float("nan"),
            "Davies-Bouldin Index": float("nan"),
            "Calinski-Harabasz Index": float("nan"),
        }

    # Sub-sample for Silhouette (expensive O(n²))
    if len(X_clean) > 5000:
        idx     = np.random.choice(len(X_clean), 5000, replace=False)
        X_sil   = X_clean[idx]
        l_sil   = l_clean[idx]
        # Re-check after sub-sampling
        if len(np.unique(l_sil)) < 2:
            sil = float("nan")
        else:
            sil = silhouette_score(X_sil, l_sil, sample_size=2000)
    else:
        sil = silhouette_score(X_clean, l_clean)

    dbi = davies_bouldin_score(X_clean, l_clean)
    chi = calinski_harabasz_score(X_clean, l_clean)

    return {
        "Silhouette Score": round(float(sil), 4),
        "Davies-Bouldin Index": round(float(dbi), 4),
        "Calinski-Harabasz Index": round(float(chi), 2),
    }


def plot_metrics_radar(metrics_all: dict) -> plt.Figure:
    """
    Draw a radar / spider chart comparing algorithms across metrics.

    Parameters
    ----------
    metrics_all : { algo_name: { metric_name: value } }
    """
    categories = ["Silhouette\nScore", "1/(DB Index)", "CH Index\n(norm)"]
    N = len(categories)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    plt.xticks(angles[:-1], categories, size=10)
    ax.set_rlabel_position(0)
    plt.yticks([0.25, 0.5, 0.75, 1.0], ["0.25", "0.50", "0.75", "1.0"], size=8)
    plt.ylim(0, 1)

    colors = plt.cm.Set2(np.linspace(0, 1, len(metrics_all)))

    # Normalise across algorithms
    all_sil = [v.get("Silhouette Score", 0) or 0 for v in metrics_all.values()]
    all_dbi = [v.get("Davies-Bouldin Index", 1) or 1 for v in metrics_all.values()]
    all_chi = [v.get("Calinski-Harabasz Index", 0) or 0 for v in metrics_all.values()]

    max_sil = max(all_sil) if max(all_sil) > 0 else 1
    min_dbi = min(all_dbi) if all_dbi else 1
    max_chi = max(all_chi) if max(all_chi) > 0 else 1

    for (algo, mdict), col in zip(metrics_all.items(), colors):
        sil = (mdict.get("Silhouette Score", 0) or 0) / max_sil
        dbi = min_dbi / (mdict.get("Davies-Bouldin Index", 1) or 1)
        chi = (mdict.get("Calinski-Harabasz Index", 0) or 0) / max_chi

        values = [sil, dbi, chi]
        values += values[:1]

        ax.plot(angles, values, "o-", linewidth=2, label=algo.upper(), color=col)
        ax.fill(angles, values, alpha=0.15, color=col)

    plt.legend(loc="upper right", bbox_to_anchor=(1.2, 1.15))
    plt.title("Algorithm Comparison", size=13, fontweight="bold", pad=20)
    plt.tight_layout()
    return fig
