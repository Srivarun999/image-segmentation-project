"""
backend/flask_api.py
Flask REST API backend for image segmentation.

Run:  python backend/flask_api.py
Endpoints:
  POST /segment   – perform segmentation
  POST /tendency  – compute cluster tendency
  GET  /health    – liveness check
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS

from algorithms.kmeans import run_kmeans
from algorithms.dbscan import run_dbscan
from algorithms.gmm    import run_gmm
from utils.cluster_tendency import hopkins_statistic, gap_statistic
from utils.metrics          import compute_metrics

app = Flask(__name__)
CORS(app)


# ── Health ─────────────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "image-segmentation-api"}), 200


# ── Segment ────────────────────────────────────────────────────────────────────
@app.route("/segment", methods=["POST"])
def segment():
    """
    Body (JSON):
    {
        "features"    : [[...], ...],   // (N, F) float matrix
        "algorithm"   : "kmeans" | "dbscan" | "gmm",
        "params"      : { ... },
        "image_shape" : [H, W, C]       // optional, for label reshape
    }

    Response:
    {
        "labels"      : [...],           // flat (N,) int array
        "n_clusters"  : int,
        "metrics"     : { ... },
        "time_ms"     : float
    }
    """
    import time
    data = request.get_json(force=True)

    features    = np.array(data["features"], dtype=np.float64)
    algorithm   = data.get("algorithm", "kmeans").lower()
    params      = data.get("params", {})

    t0 = time.time()
    if algorithm == "kmeans":
        labels = run_kmeans(features, **params)
    elif algorithm == "dbscan":
        labels = run_dbscan(features, **params)
    elif algorithm == "gmm":
        labels = run_gmm(features, **params)
    else:
        return jsonify({"error": f"Unknown algorithm: {algorithm}"}), 400

    elapsed_ms = (time.time() - t0) * 1000
    n_clusters  = int(len(np.unique(labels[labels >= 0])))

    metrics = {}
    if n_clusters >= 2:
        try:
            metrics = compute_metrics(features, labels)
        except Exception as e:
            metrics = {"error": str(e)}

    return jsonify({
        "labels":     labels.tolist(),
        "n_clusters": n_clusters,
        "metrics":    metrics,
        "time_ms":    round(elapsed_ms, 2),
    })


# ── Cluster tendency ───────────────────────────────────────────────────────────
@app.route("/tendency", methods=["POST"])
def tendency():
    """
    Body (JSON):
    {
        "features"   : [[...], ...],
        "n_samples"  : int    (Hopkins),
        "max_k"      : int    (Gap)
    }

    Response:
    {
        "hopkins" : { "value": float, "interpretation": str },
        "gap"     : { "values": [...], "optimal_k": int, "interpretation": str }
    }
    """
    data     = request.get_json(force=True)
    features = np.array(data["features"], dtype=np.float64)

    n_samples = data.get("n_samples", 150)
    max_k     = data.get("max_k", 8)

    h_val, h_interp               = hopkins_statistic(features, n_samples=n_samples)
    gap_vals, gap_k, gap_interp   = gap_statistic(features, max_k=max_k)

    return jsonify({
        "hopkins": {"value": h_val, "interpretation": h_interp},
        "gap":     {"values": gap_vals, "optimal_k": gap_k, "interpretation": gap_interp},
    })


# ── Metrics ────────────────────────────────────────────────────────────────────
@app.route("/metrics", methods=["POST"])
def metrics_endpoint():
    """
    Body: { "features": [[...]], "labels": [...] }
    Response: { metric_name: value, ... }
    """
    data     = request.get_json(force=True)
    features = np.array(data["features"], dtype=np.float64)
    labels   = np.array(data["labels"],   dtype=np.int32)
    result   = compute_metrics(features, labels)
    return jsonify(result)


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Segmentation Flask API")
    parser.add_argument("--host",  default="0.0.0.0")
    parser.add_argument("--port",  type=int, default=5000)
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    print(f"🚀  Starting Flask API on http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=args.debug)
