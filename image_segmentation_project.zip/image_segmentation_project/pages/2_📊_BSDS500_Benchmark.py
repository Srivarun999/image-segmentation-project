"""
pages/2_📊_BSDS500_Benchmark.py
Benchmark segmentation algorithms on the BSDS500 dataset.
"""

import streamlit as st
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import os

st.set_page_config(page_title="BSDS500 Benchmark", page_icon="📊", layout="wide")
st.title("📊 BSDS500 Benchmark")

st.markdown("""
Evaluate K-Means, DBSCAN, and GMM against BSDS500 human annotations using
**Boundary F-measure**, **Variation of Information**, and **Probabilistic Rand Index**.
""")

# ── Check dataset ──────────────────────────────────────────────────────────────
bsr_path = os.path.join(os.path.dirname(__file__), "..", "data", "BSR")

if not os.path.exists(bsr_path):
    st.warning("⚠️  BSDS500 dataset not found.")
    st.code("python -c \"from data.bsds500_loader import BSDS500Dataset; BSDS500Dataset.download()\"")

    col1, col2 = st.columns(2)
    with col1:
        st.info("""
**Manual download steps:**
1. Visit the [BSDS500 page](https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html)
2. Download `BSR_bsds500.tgz`
3. Extract to `data/BSR/`
        """)
    with col2:
        if st.button("🔽 Auto-download BSDS500"):
            with st.spinner("Downloading (~70 MB) …"):
                from data.bsds500_loader import BSDS500Dataset
                try:
                    BSDS500Dataset.download(bsr_path)
                    st.success("Downloaded successfully! Refresh the page.")
                except Exception as e:
                    st.error(f"Download failed: {e}")
    st.stop()

# ── Dataset loaded ─────────────────────────────────────────────────────────────
from data.bsds500_loader import BSDS500Dataset, benchmark_segmentation
from algorithms.kmeans    import run_kmeans
from algorithms.dbscan    import run_dbscan
from algorithms.gmm       import run_gmm
from utils.preprocessing  import preprocess_image

st.success("✅ BSDS500 dataset found.")

# ── Sidebar controls ───────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### Benchmark Settings")
    split      = st.selectbox("Dataset split", ["val", "test", "train"])
    max_images = st.slider("Images to evaluate", 5, 200, 20, 5)
    algorithms = st.multiselect("Algorithms", ["K-Means", "DBSCAN", "GMM"],
                                default=["K-Means", "GMM"])

    st.markdown("### Algorithm Params")
    n_clusters = st.slider("K-Means / GMM  K", 2, 20, 5)
    eps_val    = st.slider("DBSCAN  ε",      0.1, 3.0, 0.5, 0.1)
    min_samp   = st.slider("DBSCAN  min_samples", 2, 30, 5)

    run_btn = st.button("▶️  Run Benchmark")

try:
    ds = BSDS500Dataset(root=bsr_path, split=split)
    st.markdown(f"**{len(ds)} images** in the `{split}` split.")
except FileNotFoundError as e:
    st.error(str(e))
    st.stop()

# ── Run ────────────────────────────────────────────────────────────────────────
if run_btn:
    results_all = {}

    for algo in algorithms:
        st.markdown(f"#### Running {algo} …")
        prog = st.progress(0)

        def seg_func(image, _algo=algo):
            _, feats = preprocess_image(image, resize_dim=128, color_space="LAB")
            if _algo == "K-Means":
                labels = run_kmeans(feats, n_clusters=n_clusters)
            elif _algo == "DBSCAN":
                labels = run_dbscan(feats, eps=eps_val, min_samples=min_samp)
            else:
                labels = run_gmm(feats, n_components=n_clusters)
            import numpy as np
            return labels.reshape(128, 128)

        with st.spinner(f"Evaluating {algo} on {max_images} images …"):
            metrics = benchmark_segmentation(
                seg_func, ds, max_images=max_images
            )
        results_all[algo] = metrics
        prog.empty()

    # ── Table ──────────────────────────────────────────────────────────────────
    st.markdown("### Results")
    df = pd.DataFrame(results_all).T
    df.columns = ["Mean BF ↑", "Mean VI ↓", "Mean PRI ↑", "N images"]
    st.dataframe(df.style.highlight_max(["Mean BF ↑", "Mean PRI ↑"], color="#d6ffd6")
                         .highlight_min(["Mean VI ↓"], color="#d6ffd6"),
                 use_container_width=True)

    # ── Bar chart ──────────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    metrics_cols = ["Mean BF ↑", "Mean VI ↓", "Mean PRI ↑"]
    colors       = ["#667eea", "#f093fb", "#43e97b"]

    for ax, col, clr in zip(axes, metrics_cols, colors):
        vals  = [results_all[a].get("mean_" + col.split()[1].strip("↑↓"), 0) for a in results_all]
        ax.bar(list(results_all.keys()), vals, color=clr, edgecolor="#333")
        ax.set_title(col, fontsize=11)
        ax.set_ylabel("Score")
        ax.grid(axis="y", alpha=0.3)

    plt.suptitle("BSDS500 Benchmark Results", fontsize=13, fontweight="bold")
    plt.tight_layout()
    st.pyplot(fig)
