"""
pages/3_🔍_Advanced_Analysis.py
Parameter sweep, elbow analysis, and BIC/AIC plots.
"""

import streamlit as st
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

st.set_page_config(page_title="Advanced Analysis", page_icon="🔍", layout="wide")
st.title("🔍 Advanced Analysis")

from utils.preprocessing import preprocess_image
from algorithms.kmeans   import elbow_analysis, find_optimal_k_elbow
from algorithms.gmm      import bic_aic_analysis
from algorithms.dbscan   import estimate_eps

# ── Image source ───────────────────────────────────────────────────────────────
st.markdown("### 1️⃣  Load Image")

input_mode = st.radio("Source", ["Upload", "Sample"], horizontal=True)
image_np   = None

if input_mode == "Upload":
    up = st.file_uploader("Upload image", type=["jpg", "jpeg", "png", "bmp"])
    if up:
        from PIL import Image
        image_np = np.array(Image.open(up).convert("RGB"))
else:
    sample = st.selectbox("Sample", ["cameraman", "coins", "astronaut", "coffee", "chelsea"])
    from skimage import data as skdata
    mapping = dict(
        cameraman=skdata.camera, coins=skdata.coins,
        astronaut=skdata.astronaut, coffee=skdata.coffee, chelsea=skdata.chelsea
    )
    raw = mapping[sample]()
    image_np = np.stack([raw] * 3, axis=-1) if raw.ndim == 2 else raw

if image_np is None:
    st.info("Load an image above.")
    st.stop()

resize_dim  = st.slider("Resize", 64, 256, 128, 32)
color_space = st.selectbox("Color space", ["LAB", "RGB", "HSV"])
_, features = preprocess_image(image_np, resize_dim=resize_dim, color_space=color_space)
st.success(f"Feature matrix: `{features.shape}`")

# ── Elbow / K selection ────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 2️⃣  K-Means Elbow & Silhouette")

k_max = st.slider("Max K to test", 3, 20, 12)
if st.button("▶️  Run Elbow Analysis"):
    with st.spinner("Computing …"):
        inertias, sil_scores = elbow_analysis(features, k_range=range(2, k_max + 1))
    opt_k = find_optimal_k_elbow(inertias)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    ks = list(range(2, k_max + 1))

    axes[0].plot(ks, inertias, "bo-", linewidth=2)
    axes[0].axvline(opt_k, color="red", linestyle="--", label=f"Elbow K={opt_k}")
    axes[0].set_xlabel("K"); axes[0].set_ylabel("Inertia (SSE)")
    axes[0].set_title("Elbow Curve"); axes[0].legend(); axes[0].grid(alpha=0.3)

    axes[1].plot(ks, sil_scores, "gs-", linewidth=2)
    best_sil_k = ks[int(np.argmax(sil_scores))]
    axes[1].axvline(best_sil_k, color="orange", linestyle="--", label=f"Best K={best_sil_k}")
    axes[1].set_xlabel("K"); axes[1].set_ylabel("Silhouette Score")
    axes[1].set_title("Silhouette Analysis"); axes[1].legend(); axes[1].grid(alpha=0.3)

    plt.tight_layout()
    st.pyplot(fig)
    st.info(f"💡 Suggested K from elbow: **{opt_k}** | Best silhouette: **{best_sil_k}**")

# ── GMM BIC/AIC ────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 3️⃣  GMM BIC / AIC Component Selection")

gmm_max_k   = st.slider("Max components", 3, 20, 10)
cov_type    = st.selectbox("Covariance type", ["full", "tied", "diag", "spherical"])

if st.button("▶️  Run BIC/AIC"):
    with st.spinner("Fitting GMMs …"):
        bic, aic = bic_aic_analysis(features, k_range=range(2, gmm_max_k + 1), covariance_type=cov_type)

    ks = list(range(2, gmm_max_k + 1))
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(ks, bic, "r^-",  label="BIC", linewidth=2)
    ax.plot(ks, aic, "bs--", label="AIC", linewidth=2)
    opt_bic = ks[int(np.argmin(bic))]
    ax.axvline(opt_bic, color="gray", linestyle=":", label=f"Min BIC K={opt_bic}")
    ax.set_xlabel("# Components"); ax.set_ylabel("Score (lower = better)")
    ax.set_title("GMM Model Selection: BIC & AIC"); ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout()
    st.pyplot(fig)
    st.info(f"💡 BIC suggests **{opt_bic}** components.")

# ── DBSCAN eps estimation ──────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 4️⃣  DBSCAN Epsilon Estimation")

min_samp_d  = st.slider("min_samples", 2, 30, 5)
if st.button("▶️  Estimate ε"):
    with st.spinner("Computing k-NN distances …"):
        from sklearn.neighbors import NearestNeighbors
        n   = min(5000, features.shape[0])
        idx = np.random.choice(features.shape[0], n, replace=False)
        sub = features[idx]

        nbrs   = NearestNeighbors(n_neighbors=min_samp_d).fit(sub)
        dists, _ = nbrs.kneighbors(sub)
        k_dists  = np.sort(dists[:, -1])

    suggested_eps = float(np.percentile(k_dists, 90))

    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(k_dists, linewidth=1, color="#667eea")
    ax.axhline(suggested_eps, color="red", linestyle="--",
               label=f"Suggested ε ≈ {suggested_eps:.3f} (90th pct)")
    ax.set_xlabel("Points (sorted)"); ax.set_ylabel(f"{min_samp_d}-NN distance")
    ax.set_title("k-NN Distance Plot for DBSCAN ε Estimation")
    ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout()
    st.pyplot(fig)
    st.info(f"💡 Suggested DBSCAN ε ≈ **{suggested_eps:.4f}**")
