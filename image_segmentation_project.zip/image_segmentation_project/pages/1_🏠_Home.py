"""
pages/1_🏠_Home.py
Landing / documentation page for the multi-page Streamlit app.
"""

import streamlit as st

st.set_page_config(page_title="Home", page_icon="🏠", layout="wide")

st.markdown("""
<style>
.hero {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 3rem 2rem; border-radius: 16px; text-align: center; color: white;
    margin-bottom: 2rem;
}
.hero h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
.hero p  { font-size: 1.1rem; opacity: 0.9; }
.card {
    background: #fff; border-radius: 12px; padding: 1.5rem;
    box-shadow: 0 2px 10px rgba(0,0,0,.07); height: 100%;
}
.card h3 { margin-top: 0; color: #333; }
.badge {
    display: inline-block; background: #667eea; color: #fff;
    padding: 2px 10px; border-radius: 20px; font-size: 0.8rem; margin: 2px;
}
</style>

<div class="hero">
  <h1>🔬 Image Segmentation Studio</h1>
  <p>Unsupervised segmentation guided by cluster tendency evaluation</p>
</div>
""", unsafe_allow_html=True)

# ── Navigation guide ───────────────────────────────────────────────────────────
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class="card">
    <h3>📸 Main App</h3>
    Upload an image, evaluate cluster tendency with Hopkins & Gap statistics,
    then segment with K-Means, DBSCAN, or GMM. View results with interactive metrics.
    <br><br>
    <span class="badge">Hopkins</span>
    <span class="badge">Gap Stat</span>
    <span class="badge">K-Means</span>
    <span class="badge">DBSCAN</span>
    <span class="badge">GMM</span>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="card">
    <h3>📊 BSDS500 Benchmark</h3>
    Benchmark algorithms against the Berkeley Segmentation Dataset 500 using
    Boundary F-measure, Variation of Information, and Probabilistic Rand Index.
    <br><br>
    <span class="badge">BF Score</span>
    <span class="badge">Var. of Info</span>
    <span class="badge">PRI</span>
    <span class="badge">BSDS500</span>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="card">
    <h3>🔍 Advanced Analysis</h3>
    Deep-dive parameter selection: K-Means elbow curves, silhouette analysis,
    GMM BIC/AIC model selection, and DBSCAN epsilon estimation via k-NN distances.
    <br><br>
    <span class="badge">Elbow</span>
    <span class="badge">BIC/AIC</span>
    <span class="badge">ε Estimation</span>
    <span class="badge">PCA</span>
    </div>
    """, unsafe_allow_html=True)

# ── Pipeline diagram ───────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 🔄 Processing Pipeline")

steps = [
    ("📁", "Input",         "Upload image or choose a sample from scikit-image"),
    ("🎨", "Pre-process",   "Resize · Color space (RGB/LAB/HSV) · Spatial features · Blur"),
    ("📊", "Cluster Test",  "Hopkins Statistic (clusterability) · Gap Statistic (optimal K)"),
    ("🤖", "Segment",       "K-Means · DBSCAN · GMM — individually or in comparison mode"),
    ("📈", "Evaluate",      "Silhouette · Davies-Bouldin · Calinski-Harabasz · Radar chart"),
    ("🏆", "Benchmark",     "Optional BSDS500 ground-truth comparison (BF / VI / PRI)"),
]

cols = st.columns(len(steps))
for col, (icon, title, desc) in zip(cols, steps):
    col.markdown(f"""
    <div style="text-align:center; padding:1rem; background:#f8f9fa;
                border-radius:10px; height:160px;">
      <div style="font-size:2rem">{icon}</div>
      <div style="font-weight:700; margin:.5rem 0;">{title}</div>
      <div style="font-size:.8rem; color:#666;">{desc}</div>
    </div>
    """, unsafe_allow_html=True)

# ── Tech stack ─────────────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("### 🛠️ Technology Stack")

tech_cols = st.columns(4)
stack = [
    ("🌐 Frontend",  "Streamlit 1.32+"),
    ("⚙️ Backend",   "Flask 3.0 + CORS"),
    ("🧠 ML",        "scikit-learn 1.4+"),
    ("🖼️ Imaging",   "OpenCV · scikit-image · Pillow"),
]
for col, (label, value) in zip(tech_cols, stack):
    col.metric(label, value)

st.markdown("---")
st.info("👈 Use the sidebar to navigate between pages.")
