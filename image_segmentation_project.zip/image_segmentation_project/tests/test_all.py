"""
tests/test_all.py
Unit tests for the Image Segmentation Studio.
Run with:  pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
import pytest

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def small_features():
    """200-sample, 5-feature synthetic clustered dataset."""
    np.random.seed(42)
    centres = np.array([[0, 0, 0, 0, 0],
                        [5, 5, 5, 5, 5],
                        [-5, 5, -5, 5, -5]])
    X = np.vstack([
        centres[i] + np.random.randn(67, 5) * 0.8
        for i in range(3)
    ])
    np.random.shuffle(X)
    return X.astype(np.float64)


@pytest.fixture
def dummy_image():
    """Small 64×64 RGB uint8 image."""
    rng = np.random.default_rng(0)
    return rng.integers(0, 255, (64, 64, 3), dtype=np.uint8)


# ─────────────────────────────────────────────────────────────────────────────
# Pre-processing
# ─────────────────────────────────────────────────────────────────────────────

class TestPreprocessing:
    def test_output_shapes(self, dummy_image):
        from utils.preprocessing import preprocess_image
        proc, feats = preprocess_image(dummy_image, resize_dim=64)
        assert proc.shape == (64, 64, 3)
        assert feats.ndim == 2
        assert feats.shape[0] == 64 * 64

    def test_spatial_features(self, dummy_image):
        from utils.preprocessing import preprocess_image
        _, f_with    = preprocess_image(dummy_image, resize_dim=32, use_spatial=True)
        _, f_without = preprocess_image(dummy_image, resize_dim=32, use_spatial=False)
        assert f_with.shape[1] == f_without.shape[1] + 2

    @pytest.mark.parametrize("cs", ["RGB", "LAB", "HSV", "Grayscale"])
    def test_color_spaces(self, dummy_image, cs):
        from utils.preprocessing import preprocess_image
        proc, feats = preprocess_image(dummy_image, resize_dim=32, color_space=cs)
        assert feats.shape[0] == 32 * 32

    def test_gaussian_blur(self, dummy_image):
        from utils.preprocessing import preprocess_image
        _, f1 = preprocess_image(dummy_image, resize_dim=32, gaussian_blur=False)
        _, f2 = preprocess_image(dummy_image, resize_dim=32, gaussian_blur=True, blur_sigma=1.5)
        # Features should differ when blur is applied
        assert not np.allclose(f1, f2)


# ─────────────────────────────────────────────────────────────────────────────
# Cluster Tendency
# ─────────────────────────────────────────────────────────────────────────────

class TestClusterTendency:
    def test_hopkins_range(self, small_features):
        from utils.cluster_tendency import hopkins_statistic
        h, interp = hopkins_statistic(small_features, n_samples=100)
        assert 0.0 <= h <= 1.0, f"Hopkins {h} out of [0,1]"
        assert isinstance(interp, str)

    def test_hopkins_clustered_high(self, small_features):
        from utils.cluster_tendency import hopkins_statistic
        h, _ = hopkins_statistic(small_features, n_samples=100)
        assert h > 0.5, f"Expected H > 0.5 for clustered data, got {h:.4f}"

    def test_hopkins_random_near_half(self):
        from utils.cluster_tendency import hopkins_statistic
        np.random.seed(7)
        random_data = np.random.uniform(0, 1, (300, 4))
        h, _ = hopkins_statistic(random_data, n_samples=100)
        assert 0.3 < h < 0.7, f"Hopkins for random data should be ≈0.5, got {h:.4f}"

    def test_gap_statistic_returns_valid_k(self, small_features):
        from utils.cluster_tendency import gap_statistic
        gaps, opt_k, interp = gap_statistic(small_features, max_k=6, n_refs=3)
        assert len(gaps) == 6
        assert 1 <= opt_k <= 6
        assert isinstance(interp, str)


# ─────────────────────────────────────────────────────────────────────────────
# Algorithms
# ─────────────────────────────────────────────────────────────────────────────

class TestKMeans:
    def test_returns_correct_shape(self, small_features):
        from algorithms.kmeans import run_kmeans
        labels = run_kmeans(small_features, n_clusters=3)
        assert labels.shape == (small_features.shape[0],)

    def test_n_unique_clusters(self, small_features):
        from algorithms.kmeans import run_kmeans
        labels = run_kmeans(small_features, n_clusters=3)
        assert len(np.unique(labels)) == 3

    def test_elbow_analysis(self, small_features):
        from algorithms.kmeans import elbow_analysis
        inertias, sils = elbow_analysis(small_features, k_range=range(2, 6))
        assert len(inertias) == 4
        assert len(sils) == 4
        # Inertia should decrease
        assert all(inertias[i] >= inertias[i+1] for i in range(len(inertias)-1))

    def test_find_optimal_k(self):
        from algorithms.kmeans import find_optimal_k_elbow
        # Synthetic inertias with clear elbow at k=4 (index 2)
        inertias = [10000, 5000, 1000, 950, 920, 900]
        k = find_optimal_k_elbow(inertias)
        assert 2 <= k <= 6


class TestDBSCAN:
    def test_returns_correct_shape(self, small_features):
        from algorithms.dbscan import run_dbscan
        labels = run_dbscan(small_features, eps=1.0, min_samples=3)
        assert labels.shape == (small_features.shape[0],)

    def test_labels_include_valid_clusters(self, small_features):
        from algorithms.dbscan import run_dbscan
        labels = run_dbscan(small_features, eps=1.0, min_samples=3)
        # At least one cluster (label >= 0)
        assert np.any(labels >= 0)

    def test_eps_estimation(self, small_features):
        from algorithms.dbscan import estimate_eps
        eps = estimate_eps(small_features, min_samples=5)
        assert eps > 0

    def test_dbscan_summary(self, small_features):
        from algorithms.dbscan import run_dbscan, dbscan_summary
        labels  = run_dbscan(small_features, eps=1.0, min_samples=3)
        summary = dbscan_summary(labels)
        assert "n_clusters"  in summary
        assert "noise_pct"   in summary
        assert summary["n_clusters"] >= 1


class TestGMM:
    def test_returns_correct_shape(self, small_features):
        from algorithms.gmm import run_gmm
        labels = run_gmm(small_features, n_components=3)
        assert labels.shape == (small_features.shape[0],)

    def test_n_unique_components(self, small_features):
        from algorithms.gmm import run_gmm
        labels = run_gmm(small_features, n_components=3)
        assert len(np.unique(labels)) == 3

    def test_soft_assignments_shape(self, small_features):
        from algorithms.gmm import run_gmm_soft
        labels, probs = run_gmm_soft(small_features, n_components=3)
        assert probs.shape == (small_features.shape[0], 3)
        # Probabilities should sum to ~1
        assert np.allclose(probs.sum(axis=1), 1.0, atol=1e-5)

    def test_bic_aic_decreasing_then_flat(self, small_features):
        from algorithms.gmm import bic_aic_analysis
        bic, aic = bic_aic_analysis(small_features, k_range=range(2, 6))
        assert len(bic) == 4
        assert len(aic) == 4


# ─────────────────────────────────────────────────────────────────────────────
# Metrics
# ─────────────────────────────────────────────────────────────────────────────

class TestMetrics:
    def test_compute_metrics_keys(self, small_features):
        from utils.metrics import compute_metrics
        from algorithms.kmeans import run_kmeans
        labels  = run_kmeans(small_features, n_clusters=3)
        metrics = compute_metrics(small_features, labels)
        assert "Silhouette Score"        in metrics
        assert "Davies-Bouldin Index"    in metrics
        assert "Calinski-Harabasz Index" in metrics

    def test_silhouette_range(self, small_features):
        from utils.metrics import compute_metrics
        from algorithms.kmeans import run_kmeans
        labels  = run_kmeans(small_features, n_clusters=3)
        metrics = compute_metrics(small_features, labels)
        s = metrics["Silhouette Score"]
        assert -1.0 <= s <= 1.0, f"Silhouette {s} out of [-1, 1]"

    def test_dbi_positive(self, small_features):
        from utils.metrics import compute_metrics
        from algorithms.kmeans import run_kmeans
        labels  = run_kmeans(small_features, n_clusters=3)
        metrics = compute_metrics(small_features, labels)
        assert metrics["Davies-Bouldin Index"] >= 0

    def test_single_cluster_returns_nan(self, small_features):
        from utils.metrics import compute_metrics
        import math
        labels  = np.zeros(small_features.shape[0], dtype=np.int32)
        metrics = compute_metrics(small_features, labels)
        assert math.isnan(metrics["Silhouette Score"])

    def test_dbscan_noise_handled(self, small_features):
        from utils.metrics import compute_metrics
        labels = np.array([-1] * 50 + [0] * 75 + [1] * 76, dtype=np.int32)
        labels = labels[: small_features.shape[0]]
        metrics = compute_metrics(small_features, labels)
        # Should not crash; silhouette can be computed on non-noise points
        assert "Silhouette Score" in metrics


# ─────────────────────────────────────────────────────────────────────────────
# BSDS boundary metrics
# ─────────────────────────────────────────────────────────────────────────────

class TestBDSMetrics:
    @pytest.fixture
    def label_pair(self):
        np.random.seed(0)
        gt   = np.zeros((64, 64), dtype=np.int32)
        gt[32:, :] = 1
        pred = gt.copy()
        pred[30:34, :] = np.random.randint(0, 2, (4, 64))
        return pred, gt

    def test_bf_range(self, label_pair):
        from utils.bsds_metrics import boundary_f_measure
        pred, gt = label_pair
        bf = boundary_f_measure(pred, gt)
        assert 0.0 <= bf <= 1.0

    def test_perfect_bf(self):
        from utils.bsds_metrics import boundary_f_measure
        gt = np.zeros((32, 32), dtype=np.int32)
        gt[16:, :] = 1
        bf = boundary_f_measure(gt, gt)
        assert bf == pytest.approx(1.0, abs=0.01)

    def test_vi_nonneg(self, label_pair):
        from utils.bsds_metrics import variation_of_info
        pred, gt = label_pair
        vi = variation_of_info(pred, gt)
        assert vi >= 0.0

    def test_vi_perfect(self):
        from utils.bsds_metrics import variation_of_info
        gt = np.array([0]*50 + [1]*50, dtype=np.int32)
        vi = variation_of_info(gt, gt)
        assert vi == pytest.approx(0.0, abs=0.01)

    def test_pri_range(self, label_pair):
        from utils.bsds_metrics import prob_rand_index
        pred, gt = label_pair
        pri = prob_rand_index(pred, gt)
        assert 0.0 <= pri <= 1.0
