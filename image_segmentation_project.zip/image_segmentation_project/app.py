"""
Unsupervised Image Segmentation: Evaluating Cluster Tendency for Optimal Segmentation
Main Streamlit Application
"""

import streamlit as st
import numpy as np
from PIL import Image
import io
import time
import requests
import base64

from utils.preprocessing import preprocess_image, extract_features
from utils.cluster_tendency import hopkins_statistic, gap_statistic
from utils.metrics import compute_metrics, plot_metrics_radar
from algorithms.kmeans import run_kmeans
from algorithms.dbscan import run_dbscan
from algorithms.gmm import run_gmm
from utils.visualization import (
    plot_segmented_image,
    plot_cluster_tendency_result,
    plot_elbow_curve,
    plot_side_by_side,
    plot_feature_space
)

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Image Segmentation Studio",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.4rem; font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        text-align: center; padding: 1rem 0;
    }
    .sub-header { color: #6c757d; text-align: center; margin-bottom: 2rem; }
    .metric-card {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        padding: 1rem; border-radius: 12px; text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,.08);
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; color: #333; }
    .metric-label { font-size: 0.85rem; color: #666; margin-top: 4px; }
    .status-good  { color: #28a745; font-weight: 600; }
    .status-warn  { color: #ffc107; font-weight: 600; }
    .status-bad   { color: #dc3545; font-weight: 600; }
    .section-card {
        background: #fff; border-radius: 14px;
        padding: 1.5rem; box-shadow: 0 2px 12px rgba(0,0,0,.07); margin-bottom: 1rem;
    }
    .stButton > button {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: #fff; border: none; border-radius: 8px;
        padding: .6rem 2rem; font-weight: 600; width: 100%;
    }
    .stButton > button:hover { opacity: .9; }
</style>
""", unsafe_allow_html=True)

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown('<h1 class="main-header">🔬 Image Segmentation Studio</h1>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-header">Unsupervised segmentation with cluster tendency evaluation · '
    'K-Means · DBSCAN · GMM</p>',
    unsafe_allow_html=True
)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image("assets/logo.png", use_column_width=True) if __import__("os").path.exists("assets/logo.png") else None
    st.markdown("## ⚙️ Configuration")

    # ── Image upload ───────────────────────────────────────────────────────────
    st.markdown("### 📁 Image Input")
    input_mode = st.radio("Source", ["Upload Image", "Sample Image"], horizontal=True)

    uploaded_file = None
    sample_name   = None
    if input_mode == "Upload Image":
        uploaded_file = st.file_uploader(
            "Upload (JPG/PNG/BMP)", type=["jpg", "jpeg", "png", "bmp"]
        )
    else:
        sample_name = st.selectbox(
            "Choose sample",
            ["cameraman", "coins", "astronaut", "coffee", "chelsea"]
        )

    # ── Pre-processing ─────────────────────────────────────────────────────────
    st.markdown("### 🎨 Pre-processing")
    resize_dim     = st.slider("Resize (px)", 64, 512, 256, 32)
    color_space    = st.selectbox("Color space", ["RGB", "LAB", "HSV", "Grayscale"])
    use_spatial    = st.checkbox("Include spatial features", value=True)
    gaussian_blur  = st.checkbox("Apply Gaussian blur",     value=False)
    blur_sigma     = st.slider("Blur sigma", 0.5, 5.0, 1.0, 0.5) if gaussian_blur else None

    # ── Cluster tendency ───────────────────────────────────────────────────────
    st.markdown("### 📊 Cluster Tendency")
    run_hopkins  = st.checkbox("Hopkins Statistic",  value=True)
    run_gap      = st.checkbox("Gap Statistic",       value=True)
    n_samples_h  = st.slider("Hopkins samples",  50,  500, 150, 50)
    max_k_gap    = st.slider("Gap max K",          2,   15,   8,   1)

    # ── Algorithm ─────────────────────────────────────────────────────────────
    st.markdown("### 🤖 Segmentation Algorithm")
    algorithm = st.selectbox("Algorithm", ["K-Means", "DBSCAN", "GMM", "All (Compare)"])

    if algorithm in ("K-Means", "All (Compare)"):
        st.markdown("**K-Means parameters**")
        n_clusters_km = st.slider("# clusters", 2, 20, 5, 1)
        km_init       = st.selectbox("Init method", ["k-means++", "random"])
        km_max_iter   = st.slider("Max iterations", 100, 1000, 300, 100)

    if algorithm in ("DBSCAN", "All (Compare)"):
        st.markdown("**DBSCAN parameters**")
        eps_val    = st.slider("Epsilon (ε)", 0.01, 5.0, 0.5, 0.05)
        min_samp   = st.slider("Min samples",   2,   50,   5,   1)
        db_metric  = st.selectbox("Distance metric", ["euclidean", "manhattan", "cosine"])

    if algorithm in ("GMM", "All (Compare)"):
        st.markdown("**GMM parameters**")
        n_comp_gmm    = st.slider("# components",       2, 20, 5, 1)
        gmm_cov_type  = st.selectbox("Covariance type", ["full", "tied", "diag", "spherical"])
        gmm_max_iter  = st.slider("Max iterations",   50, 500, 200, 50)

    # ── Backend ────────────────────────────────────────────────────────────────
    st.markdown("### 🌐 Backend")
    use_flask = st.checkbox("Use Flask API backend", value=False)
    flask_url = st.text_input("Flask URL", "http://localhost:5000") if use_flask else None

    run_btn = st.button("🚀 Run Segmentation", type="primary")

# ── Main content ───────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(
    ["📸 Input & Tendency", "🎯 Segmentation Results", "📈 Metrics & Analysis", "ℹ️ About"]
)

# ── Helpers ────────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_sample_image(name: str) -> np.ndarray:
    from skimage import data as skdata, color
    mapping = {
        "cameraman": skdata.camera,
        "coins":     skdata.coins,
        "astronaut": skdata.astronaut,
        "coffee":    skdata.coffee,
        "chelsea":   skdata.chelsea,
    }
    img = mapping[name]()
    if img.ndim == 2:
        img = np.stack([img] * 3, axis=-1)
    return img

def get_image() -> np.ndarray | None:
    if input_mode == "Upload Image" and uploaded_file:
        pil_img = Image.open(uploaded_file).convert("RGB")
        return np.array(pil_img)
    elif input_mode == "Sample Image" and sample_name:
        return load_sample_image(sample_name)
    return None

# ── Tab 1: Input & Tendency ────────────────────────────────────────────────────
with tab1:
    image_np = get_image()

    if image_np is None:
        st.info("⬅️  Upload an image or select a sample image from the sidebar.")
        st.stop()

    col_img, col_tend = st.columns([1, 1], gap="large")

    with col_img:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.markdown("### 🖼️ Original Image")
        st.image(image_np, use_column_width=True, caption=f"Shape: {image_np.shape}")

        proc_params = dict(
            resize_dim=resize_dim, color_space=color_space,
            use_spatial=use_spatial, gaussian_blur=gaussian_blur,
            blur_sigma=blur_sigma
        )
        processed, feature_matrix = preprocess_image(image_np, **proc_params)
        st.markdown(f"**Feature matrix:** `{feature_matrix.shape}`")
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.markdown("### 🔭 Feature Space (PCA 2D)")
        fig_fs = plot_feature_space(feature_matrix, max_points=2000)
        st.pyplot(fig_fs)
        st.markdown('</div>', unsafe_allow_html=True)

    with col_tend:
        st.markdown('<div class="section-card">', unsafe_allow_html=True)
        st.markdown("### 📊 Cluster Tendency Analysis")

        tendency_results = {}

        if run_hopkins:
            with st.spinner("Computing Hopkins Statistic…"):
                h_stat, h_interp = hopkins_statistic(feature_matrix, n_samples=n_samples_h)
            tendency_results["Hopkins"] = (h_stat, h_interp)

            css_class = "status-good" if h_stat > 0.75 else ("status-warn" if h_stat > 0.5 else "status-bad")
            st.markdown(
                f"**Hopkins Statistic:** "
                f'<span class="{css_class}">{h_stat:.4f}</span> — {h_interp}',
                unsafe_allow_html=True
            )
            fig_h = plot_cluster_tendency_result("Hopkins", h_stat, threshold=0.75)
            st.pyplot(fig_h)

        if run_gap:
            with st.spinner("Computing Gap Statistic (this may take a moment)…"):
                gap_vals, gap_k, gap_interp = gap_statistic(feature_matrix, max_k=max_k_gap)
            tendency_results["Gap"] = (gap_vals, gap_k, gap_interp)
            st.markdown(f"**Gap Statistic optimal K:** `{gap_k}` — {gap_interp}")
            fig_gap = plot_elbow_curve(gap_vals, gap_k)
            st.pyplot(fig_gap)

        if tendency_results:
            st.success("✅ Cluster tendency analysis complete!")
        else:
            st.warning("Enable at least one tendency measure in the sidebar.")

        st.markdown('</div>', unsafe_allow_html=True)

# ── Tab 2: Segmentation Results ────────────────────────────────────────────────
with tab2:
    if not run_btn:
        st.info("Configure settings in the sidebar and click **🚀 Run Segmentation**.")
        st.stop()

    image_np = get_image()
    if image_np is None:
        st.warning("No image loaded.")
        st.stop()

    processed, feature_matrix = preprocess_image(image_np, **proc_params)

    def build_params() -> dict:
        p = {}
        if algorithm in ("K-Means", "All (Compare)"):
            p["kmeans"] = dict(n_clusters=n_clusters_km, init=km_init, max_iter=km_max_iter)
        if algorithm in ("DBSCAN", "All (Compare)"):
            p["dbscan"] = dict(eps=eps_val, min_samples=min_samp, metric=db_metric)
        if algorithm in ("GMM", "All (Compare)"):
            p["gmm"]    = dict(n_components=n_comp_gmm, covariance_type=gmm_cov_type, max_iter=gmm_max_iter)
        return p

    params   = build_params()
    results  = {}

    progress = st.progress(0, text="Starting segmentation…")
    algo_list = list(params.keys())

    for i, algo_key in enumerate(algo_list):
        progress.progress((i) / len(algo_list), text=f"Running {algo_key.upper()}…")
        t0 = time.time()

        if use_flask and flask_url:
            # ── Flask API path ─────────────────────────────────────────────────
            payload = {
                "features": feature_matrix.tolist(),
                "algorithm": algo_key,
                "params": params[algo_key],
                "image_shape": list(image_np.shape)
            }
            try:
                resp = requests.post(f"{flask_url}/segment", json=payload, timeout=120)
                resp.raise_for_status()
                data = resp.json()
                labels = np.array(data["labels"])
            except Exception as e:
                st.error(f"Flask API error: {e}")
                labels = None
        else:
            # ── Local path ─────────────────────────────────────────────────────
            if algo_key == "kmeans":
                labels = run_kmeans(feature_matrix, **params[algo_key])
            elif algo_key == "dbscan":
                labels = run_dbscan(feature_matrix, **params[algo_key])
            elif algo_key == "gmm":
                labels = run_gmm(feature_matrix, **params[algo_key])
            else:
                labels = None

        elapsed = time.time() - t0
        if labels is not None:
            results[algo_key] = {"labels": labels, "time": elapsed, "params": params[algo_key]}

        progress.progress((i + 1) / len(algo_list), text=f"{algo_key.upper()} done in {elapsed:.2f}s")

    progress.empty()

    if not results:
        st.error("No segmentation results.")
        st.stop()

    st.session_state["results"]      = results
    st.session_state["feature_matrix"] = feature_matrix
    st.session_state["image_np"]     = image_np

    # ── Display results ────────────────────────────────────────────────────────
    for algo_key, res in results.items():
        st.markdown(f'<div class="section-card">', unsafe_allow_html=True)
        st.markdown(f"### 🎨 {algo_key.upper()} Segmentation")

        labels_img = res["labels"].reshape(image_np.shape[:2])
        n_found    = len(np.unique(labels_img[labels_img >= 0]))

        m1, m2, m3 = st.columns(3)
        m1.markdown(f'<div class="metric-card"><div class="metric-value">{n_found}</div><div class="metric-label">Segments found</div></div>', unsafe_allow_html=True)
        m2.markdown(f'<div class="metric-card"><div class="metric-value">{res["time"]:.2f}s</div><div class="metric-label">Runtime</div></div>', unsafe_allow_html=True)
        noise_pct = (np.sum(labels_img == -1) / labels_img.size * 100) if algo_key == "dbscan" else 0
        m3.markdown(f'<div class="metric-card"><div class="metric-value">{noise_pct:.1f}%</div><div class="metric-label">Noise pixels (DBSCAN)</div></div>', unsafe_allow_html=True)

        col_a, col_b = st.columns(2)
        with col_a:
            fig_seg = plot_segmented_image(image_np, labels_img, title=f"{algo_key.upper()} Labels")
            st.pyplot(fig_seg)
        with col_b:
            fig_side = plot_side_by_side(image_np, labels_img)
            st.pyplot(fig_side)

        st.markdown('</div>', unsafe_allow_html=True)

# ── Tab 3: Metrics & Analysis ──────────────────────────────────────────────────
with tab3:
    if "results" not in st.session_state:
        st.info("Run segmentation first (Tab 2).")
        st.stop()

    results        = st.session_state["results"]
    feature_matrix = st.session_state["feature_matrix"]
    image_np       = st.session_state["image_np"]

    st.markdown("### 📈 Clustering Quality Metrics")
    metrics_all = {}

    for algo_key, res in results.items():
        labels = res["labels"]
        if len(np.unique(labels[labels >= 0])) < 2:
            st.warning(f"{algo_key.upper()}: fewer than 2 clusters — metrics skipped.")
            continue
        mdict = compute_metrics(feature_matrix, labels)
        metrics_all[algo_key] = mdict

    if not metrics_all:
        st.warning("No valid metric results.")
        st.stop()

    # ── Table ──────────────────────────────────────────────────────────────────
    import pandas as pd
    df_metrics = pd.DataFrame(metrics_all).T.round(4)
    st.dataframe(df_metrics.style.highlight_min(["Davies-Bouldin Index"], color="#ffd6d6")
                              .highlight_max(["Silhouette Score", "Calinski-Harabasz Index"], color="#d6ffd6"),
                 use_container_width=True)

    # ── Radar chart ────────────────────────────────────────────────────────────
    st.markdown("### 🕸️ Radar Comparison")
    fig_radar = plot_metrics_radar(metrics_all)
    st.pyplot(fig_radar)

    # ── Per-algorithm insight ──────────────────────────────────────────────────
    st.markdown("### 💡 Insights")
    for algo_key, mdict in metrics_all.items():
        with st.expander(f"📌 {algo_key.upper()} detailed metrics"):
            c1, c2, c3 = st.columns(3)
            c1.metric("Silhouette Score",      f'{mdict.get("Silhouette Score",0):.4f}',
                       delta="Higher is better")
            c2.metric("Davies-Bouldin Index",  f'{mdict.get("Davies-Bouldin Index",0):.4f}',
                       delta="Lower is better")
            c3.metric("Calinski-Harabasz",     f'{mdict.get("Calinski-Harabasz Index",0):.1f}',
                       delta="Higher is better")

# ── Tab 4: About ───────────────────────────────────────────────────────────────
with tab4:
    st.markdown("""
    ## 🔬 About This Project

    **Unsupervised Image Segmentation: Evaluating Cluster Tendency for Optimal Segmentation**

    This application provides a complete pipeline for image segmentation using unsupervised
    machine learning, guided by statistical cluster tendency evaluation.

    ### 🧠 Methodology
    1. **Pre-processing** – Resize, color-space conversion, spatial feature augmentation
    2. **Cluster Tendency** – Hopkins Statistic & Gap Statistic determine *whether* clustering
       is warranted before running any algorithm
    3. **Segmentation** – K-Means, DBSCAN, and GMM with tunable hyper-parameters
    4. **Evaluation** – Silhouette Score, Davies-Bouldin Index, Calinski-Harabasz Index

    ### 📚 Dataset
    - **Berkeley Segmentation Dataset 500 (BSDS500)** — 500 natural images with human
      annotations, used for ground-truth comparison and algorithm benchmarking.

    ### 🤖 Algorithms
    | Algorithm | Best for | Key parameter |
    |-----------|----------|---------------|
    | K-Means   | Compact, spherical clusters | # clusters K |
    | DBSCAN    | Arbitrary shapes, noise tolerance | ε, min_samples |
    | GMM       | Soft / probabilistic assignments | # components |

    ### 📊 Statistical Guidance
    | Measure | Interpretation |
    |---------|----------------|
    | Hopkins > 0.75 | Strong clustering tendency |
    | Hopkins 0.5–0.75 | Moderate tendency |
    | Hopkins < 0.5 | Data is random — avoid clustering |
    | Gap Statistic | Suggests optimal K |

    ### 🛠️ Tech Stack
    `Python 3.10+` · `Streamlit` · `Flask` · `scikit-learn` · `OpenCV` · `scikit-image`
    · `NumPy` · `Matplotlib`

    ---
    *Project by: Unsupervised Vision Lab*
    """)
