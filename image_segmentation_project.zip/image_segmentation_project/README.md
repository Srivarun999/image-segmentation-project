# 🔬 Unsupervised Image Segmentation Studio

**Evaluating Cluster Tendency for Optimal Segmentation**

A web-based application combining classical clustering algorithms with statistical
cluster tendency assessment to guide unsupervised image segmentation.

---

## 📁 Project Structure

```
image_segmentation_project/
│
├── app.py                          # Main Streamlit application
│
├── algorithms/
│   ├── kmeans.py                   # K-Means + elbow analysis
│   ├── dbscan.py                   # DBSCAN + eps estimation
│   └── gmm.py                      # Gaussian Mixture Model + BIC/AIC
│
├── utils/
│   ├── preprocessing.py            # Image pre-processing & feature extraction
│   ├── cluster_tendency.py         # Hopkins & Gap statistics
│   ├── metrics.py                  # Silhouette, Davies-Bouldin, CH metrics
│   ├── visualization.py            # All Matplotlib plotting helpers
│   └── bsds_metrics.py             # BF, VI, PRI for BSDS benchmarking
│
├── backend/
│   └── flask_api.py                # Optional Flask REST API backend
│
├── data/
│   ├── bsds500_loader.py           # BSDS500 dataset loader & benchmark
│   └── BSR/                        # ← place extracted BSDS500 here
│
├── pages/
│   ├── 2_📊_BSDS500_Benchmark.py  # Benchmark page
│   └── 3_🔍_Advanced_Analysis.py  # Elbow, BIC/AIC, eps estimation
│
├── assets/                         # Optional logo / images
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

### 1. Create a virtual environment

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run the Streamlit app

```bash
streamlit run app.py
```

The app opens at **http://localhost:8501**

---

## 🌐 Optional: Flask Backend

```bash
python backend/flask_api.py --port 5000
```

Enable **"Use Flask API backend"** in the Streamlit sidebar and enter
`http://localhost:5000` as the URL. The Streamlit app will delegate
all segmentation work to the Flask service.

---

## 📚 BSDS500 Dataset

### Automatic download

```python
from data.bsds500_loader import BSDS500Dataset
BSDS500Dataset.download()   # saves to data/BSR/
```

### Manual download

1. Visit https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html
2. Download `BSR_bsds500.tgz`
3. Extract so that `data/BSR/BSDS500/data/images/train/` exists

Once the dataset is present, the **BSDS500 Benchmark** page becomes available.

---

## 🧠 Methodology

| Step | Component | Purpose |
|------|-----------|---------|
| 1 | Pre-processing | Resize, colour-space conversion, spatial features |
| 2 | Hopkins Statistic | Is clustering even warranted? (H > 0.75 → yes) |
| 3 | Gap Statistic | Suggests optimal K before running K-Means/GMM |
| 4 | Segmentation | K-Means / DBSCAN / GMM on pixel features |
| 5 | Evaluation | Silhouette, Davies-Bouldin, Calinski-Harabasz |
| 6 | Benchmark | BF, VI, PRI against BSDS500 ground truth |

---

## 📊 Algorithms

### K-Means
- Compact spherical clusters
- Parameters: K, init method, max iterations
- Guidance: elbow curve + Gap Statistic

### DBSCAN
- Arbitrary cluster shapes, handles noise
- Parameters: ε (epsilon), min_samples
- Guidance: k-NN distance plot for ε selection

### GMM (Gaussian Mixture Model)
- Soft / probabilistic cluster assignments
- Parameters: components, covariance type
- Guidance: BIC / AIC model selection

---

## 🔑 API Endpoints (Flask)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/health`   | Liveness check |
| POST | `/segment`  | Run segmentation on feature matrix |
| POST | `/tendency` | Compute Hopkins & Gap statistics |
| POST | `/metrics`  | Compute clustering quality metrics |

---

## 📦 Dependencies

| Package | Role |
|---------|------|
| `streamlit` | Web UI |
| `flask` | REST API backend |
| `scikit-learn` | ML algorithms + metrics |
| `scikit-image` | Sample images |
| `opencv-python-headless` | Image I/O & processing |
| `scipy` | Statistical computations |
| `matplotlib` | Visualisations |

---

## 🏷️ Keywords

Unsupervised Image Segmentation · Cluster Tendency Evaluation ·
K-Means · DBSCAN · GMM · Hopkins Statistic · Gap Statistic ·
Streamlit · Flask · BSDS500 · Python · Machine Learning
