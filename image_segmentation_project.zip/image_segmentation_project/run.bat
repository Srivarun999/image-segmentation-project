@echo off
REM run.bat  –  Windows convenience launcher
REM Usage:
REM   run.bat app      → start Streamlit
REM   run.bat flask    → start Flask backend
REM   run.bat test     → run pytest
REM   run.bat install  → create venv + install requirements

SET MODE=%1
IF "%MODE%"=="" SET MODE=app

IF "%MODE%"=="install" (
    echo Creating virtual environment...
    python -m venv venv
    call venv\Scripts\activate
    pip install --upgrade pip
    pip install -r requirements.txt
    echo Installation complete.
    goto :EOF
)

IF EXIST venv\Scripts\activate (
    call venv\Scripts\activate
) ELSE (
    echo No venv found, using system Python
)

IF "%MODE%"=="app" (
    echo Starting Streamlit app on http://localhost:8501
    streamlit run app.py --server.port 8501
    goto :EOF
)

IF "%MODE%"=="flask" (
    echo Starting Flask API on http://localhost:5000
    python backend\flask_api.py --debug
    goto :EOF
)

IF "%MODE%"=="test" (
    echo Running tests...
    pytest tests\ -v --tb=short
    goto :EOF
)

echo Unknown mode: %MODE%
echo Usage: run.bat [install^|app^|flask^|test]
